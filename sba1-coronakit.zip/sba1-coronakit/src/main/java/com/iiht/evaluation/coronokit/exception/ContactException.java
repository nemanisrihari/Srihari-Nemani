package com.iiht.evaluation.coronokit.exception;

public class ContactException extends Exception {
	public ContactException(String errMsg) {
		super(errMsg);
	}
}
